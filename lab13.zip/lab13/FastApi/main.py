
from fastapi import FastAPI
from my_fastapi_app import post

app = FastAPI()

app.include_router(post.router)
