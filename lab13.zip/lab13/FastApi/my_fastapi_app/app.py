from fastapi import FastAPI, HTTPException, Path, Body
from typing import List, Dict

app = FastAPI()

# Імпровізована база даних для збереження постів
posts_db: Dict[int, Dict[str, str]] = {
    1: {"title": "Перший пост", "content": "Це вміст першого поста."},
    2: {"title": "Другий пост", "content": "Це вміст другого поста."}
}

# Кінцева точка для версії
@app.get("/version")
async def version():
    return {"version": "1.0"}

# Кінцева точка для отримання всіх постів
@app.get("/posts")
async def get_posts():
    return posts_db

# Кінцева точка для створення нового поста
@app.post("/posts")
async def create_post(title: str = Body(...), content: str = Body(...)):
    new_id = max(posts_db.keys()) + 1
    posts_db[new_id] = {"title": title, "content": content}
    return {"message": "Пост успішно створено", "post_id": new_id}

# Кінцева точка для оновлення поста за його ідентифікатором
@app.put("/posts/{post_id}")
async def update_post(post_id: int = Path(..., title="Ідентифікатор поста"),
                      title: str = Body(...), content: str = Body(...)):
    if post_id not in posts_db:
        raise HTTPException(status_code=404, detail="Пост не знайдено")
    posts_db[post_id] = {"title": title, "content": content}
    return {"message": f"Пост з ідентифікатором {post_id} оновлено"}

# Кінцева точка для видалення поста за його ідентифікатором
@app.delete("/posts/{post_id}")
async def delete_post(post_id: int = Path(..., title="Ідентифікатор поста")):
    if post_id not in posts_db:
        raise HTTPException(status_code=404, detail="Пост не знайдено")
    del posts_db[post_id]
    return {"message": f"Пост з ідентифікатором {post_id} видалено"}

# Кінцева точка для отримання статистики
@app.get("/stats")
async def get_stats():
    return {"version_requests": 0, "posts_requests": 0, "stats_requests": 0}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
