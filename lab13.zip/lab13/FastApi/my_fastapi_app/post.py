# post.py

from fastapi import APIRouter
from models import Post  # Змінено імпорт

router = APIRouter()

@router.post("/posts/")
async def create_post(post: Post):
    # Логіка для створення поста
    return {"message": "Post created successfully"}

@router.get("/posts/")
async def get_posts():
    # Логіка для отримання всіх постів
    return [{"title": "Example Post", "content": "This is an example post"}]
